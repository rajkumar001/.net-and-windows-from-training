﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;

namespace Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {


            //var fileName = @"C:\ExcelFile.xlsx";
            //var connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text\""; ;
            //using (var conn = new OleDbConnection(connectionString))
            //{
            //    conn.Open();

            //    var sheets = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            //    using (var cmd = conn.CreateCommand())
            //    {
            //        cmd.CommandText = "SELECT * FROM [" + sheets.Rows[0]["TABLE_NAME"].ToString() + "] ";

            //        var adapter = new OleDbDataAdapter(cmd);
            //        var ds = new DataSet();
            //        adapter.Fill(ds);
            //    }
            //}




            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;
            int flag = 0;
            for (int i = 2; i <= _lastRow; i++)
            {


                String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);

                if (textBox1.Text == str)
                {
                    textBox2.Text = Convert.ToString((range.Cells[i, 2] as Excel.Range).Value2);
                    textBox3.Text = Convert.ToString((range.Cells[i, 3] as Excel.Range).Value2);
                    textBox4.Text = Convert.ToString((range.Cells[i, 4] as Excel.Range).Value2);
                    textBox9.Text = Convert.ToString((range.Cells[i, 5] as Excel.Range).Value2);
                    textBox6.Text = Convert.ToString((range.Cells[i, 6] as Excel.Range).Value2);
                    textBox7.Text = Convert.ToString((range.Cells[i, 7] as Excel.Range).Value2);
                    textBox8.Text = Convert.ToString((range.Cells[i, 8] as Excel.Range).Value2);
                    textBox5.Text = Convert.ToString((range.Cells[i, 9] as Excel.Range).Value2);

                    flag = 1;
                    break;
                }

            }
            if (flag == 0)
            {
                MessageBox.Show("not found");
            }



            xlWorkBook.Close(true, misValue, misValue);


            xlSheet1 = null;
            xlWorkBook = null;
            xlApp.Quit();

            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            //int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            //int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;
            //int flag = 0;
            //for (int i = 2; i <= _lastRow; i++)
            //{


            //    String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);

            //    if (textBox1.Text == str)
            //    {
            textBox1.Text = Convert.ToString((range.Cells[2, 1] as Excel.Range).Value2);
            textBox2.Text = Convert.ToString((range.Cells[2, 2] as Excel.Range).Value2);
            textBox3.Text = Convert.ToString((range.Cells[2, 3] as Excel.Range).Value2);
            textBox4.Text = Convert.ToString((range.Cells[2, 4] as Excel.Range).Value2);
            textBox9.Text = Convert.ToString((range.Cells[2, 5] as Excel.Range).Value2);
            textBox6.Text = Convert.ToString((range.Cells[2, 6] as Excel.Range).Value2);
            textBox7.Text = Convert.ToString((range.Cells[2, 7] as Excel.Range).Value2);
            textBox8.Text = Convert.ToString((range.Cells[2, 8] as Excel.Range).Value2);
            textBox5.Text = Convert.ToString((range.Cells[2, 9] as Excel.Range).Value2);

            //        flag = 1;
            //        break;
            //    }

            //}
            //if (flag == 0)
            //{
            //    MessageBox.Show("not found");
            //}



            xlWorkBook.Close(true, misValue, misValue);


            xlSheet1 = null;
            xlWorkBook = null;
            xlApp.Quit();

            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            //int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;
            //int flag = 0;
            //for (int i = 2; i <= _lastRow; i++)
            //{


            //    String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);

            //    if (textBox1.Text == str)
            //    {
            textBox1.Text = Convert.ToString((range.Cells[_lastRow, 1] as Excel.Range).Value2);
            textBox2.Text = Convert.ToString((range.Cells[_lastRow, 2] as Excel.Range).Value2);
            textBox3.Text = Convert.ToString((range.Cells[_lastRow, 3] as Excel.Range).Value2);
            textBox4.Text = Convert.ToString((range.Cells[_lastRow, 4] as Excel.Range).Value2);
            textBox9.Text = Convert.ToString((range.Cells[_lastRow, 5] as Excel.Range).Value2);
            textBox6.Text = Convert.ToString((range.Cells[_lastRow, 6] as Excel.Range).Value2);
            textBox7.Text = Convert.ToString((range.Cells[_lastRow, 7] as Excel.Range).Value2);
            textBox8.Text = Convert.ToString((range.Cells[_lastRow, 8] as Excel.Range).Value2);
            textBox5.Text = Convert.ToString((range.Cells[_lastRow, 9] as Excel.Range).Value2);

            //        flag = 1;
            //        break;
            //    }

            //}
            //if (flag == 0)
            //{
            //    MessageBox.Show("not found");
            //}



            xlWorkBook.Close(true, misValue, misValue);


            xlSheet1 = null;
            xlWorkBook = null;
            xlApp.Quit();

            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //var fileName = @"d:\\csharp-Excel.xls";
            //var connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text\""; ;
            //using (var conn = new OleDbConnection(connectionString))
            //{
            //    conn.Open();

            //    var sheets = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            //    using (var cmd = conn.CreateCommand())
            //    {
            //        cmd.CommandText = "SELECT * FROM [" + sheets.Rows[0]["TABLE_NAME"].ToString() + "] ";

            //        var adapter = new OleDbDataAdapter(cmd);
            //        var ds = new DataSet();
            //        adapter.Fill(ds);

            //    }
            //}


            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;


            for (int i = 2; i <= _lastRow; i++)
            {
                if (i > 2)
                {
                    String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);
                    if (textBox1.Text == str)
                    {

                        int j = i - 1;
                        textBox1.Text = Convert.ToString((range.Cells[j, 1] as Excel.Range).Value2);
                        textBox2.Text = Convert.ToString((range.Cells[j, 2] as Excel.Range).Value2);
                        textBox3.Text = Convert.ToString((range.Cells[j, 3] as Excel.Range).Value2);
                        textBox4.Text = Convert.ToString((range.Cells[j, 4] as Excel.Range).Value2);
                        textBox9.Text = Convert.ToString((range.Cells[j, 5] as Excel.Range).Value2);
                        textBox6.Text = Convert.ToString((range.Cells[j, 6] as Excel.Range).Value2);
                        textBox7.Text = Convert.ToString((range.Cells[j, 7] as Excel.Range).Value2);
                        textBox8.Text = Convert.ToString((range.Cells[j, 8] as Excel.Range).Value2);
                        textBox5.Text = Convert.ToString((range.Cells[j, 9] as Excel.Range).Value2);


                        break;
                    }

                }
                else
                {
                    MessageBox.Show("no previous record");
                    break;
                }

            }

            xlWorkBook.Close(true, misValue, misValue);


            xlSheet1 = null;
            xlWorkBook = null;
            xlApp.Quit();

            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;


            for (int i = 2; i <= _lastRow; i++)
            {
                if (i<_lastRow)
                {
                    String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);
                    if (textBox1.Text == str)
                    {
                        int j = i + 1;
                        textBox1.Text = Convert.ToString((range.Cells[j, 1] as Excel.Range).Value2);
                        textBox2.Text = Convert.ToString((range.Cells[j, 2] as Excel.Range).Value2);
                        textBox3.Text = Convert.ToString((range.Cells[j, 3] as Excel.Range).Value2);
                        textBox4.Text = Convert.ToString((range.Cells[j, 4] as Excel.Range).Value2);
                        textBox9.Text = Convert.ToString((range.Cells[j, 5] as Excel.Range).Value2);
                        textBox6.Text = Convert.ToString((range.Cells[j, 6] as Excel.Range).Value2);
                        textBox7.Text = Convert.ToString((range.Cells[j, 7] as Excel.Range).Value2);
                        textBox8.Text = Convert.ToString((range.Cells[j, 8] as Excel.Range).Value2);
                        textBox5.Text = Convert.ToString((range.Cells[j, 9] as Excel.Range).Value2);


                        break;
                    }


                }

                else
                {
                    MessageBox.Show("no next record");
                    break;
                }
            }

                xlWorkBook.Close(true, misValue, misValue);


                xlSheet1 = null;
                xlWorkBook = null;
                xlApp.Quit();

                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }
    }
