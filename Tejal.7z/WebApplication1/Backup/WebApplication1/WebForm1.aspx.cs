﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpCookie Cookie = new HttpCookie("Username");
            Cookie.Value = TextBox1.Text;
            Cookie.Expires = DateTime.Now.AddHours(1);
            Response.Cookies.Add(Cookie);
            Response.Redirect("ShowInfo.aspx"); 
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}