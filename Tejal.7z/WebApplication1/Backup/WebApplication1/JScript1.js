﻿function validate() {
    var employee;
    var FirstName;
    var LastNAme;
    var Address;
    var DOB;
    var contact;
    var designation;
    var salary;
    var department;
    var isError = false;
    employee = document.getElementById('TextBox1').value;
    FirstName = document.getElementById('TextBox2').value;
    LastNAme = document.getElementById('TextBox3').value;
    Address = document.getElementById('TextBox4').value;
    DOB = document.getElementById('Calendar1').value;
    contact = document.getElementById('TextBox6').value;
    salary = document.getElementById('TextBox8').value;
    var letters = /^[A-Za-z]+$/;
    var phoneno = /^\d{10}$/; 
    if (employee == "") {
        document.getElementById('Label1').innerHTML = 'Employee ID should not be empty';
        isError = true;
    }
     if (FirstName == "") {
         document.getElementById('Label2').innerHTML = 'First Name should not be empty';
         isError = true;
     }
    else if (!FirstName.match(letters)) {
         document.getElementById('Label2').innerHTML = 'First Name should not be numeric';
         isError = true;
     }
     if (LastNAme == "") {
         document.getElementById('Label3').innerHTML = 'Last Name should not be empty';
         isError = true;
     }
     else if (!LastNAme.match(letters)) {
         document.getElementById('Label3').innerHTML = 'Last Name should not be numeric';
         isError = true;
     }
     if (Address == "") {
         document.getElementById('Label4').innerHTML = 'Address should not be empty';
         isError = true;
     }
     if (DOB == "") {
         document.getElementById('Label5').innerHTML = 'Date of birth should not be empty';
         isError = true;
     }
     if (contact == "") {
         document.getElementById('Label6').innerHTML = 'Contact should not be empty';
         isError = true;
     }
     
     else if (!contact.match(phoneno)) {
         document.getElementById('Label6').innerHTML = 'Enter valid contact';
         isError = true;
     }
    
     if (salary == "") {
         document.getElementById('Label8').innerHTML = 'Salary should not be empty';
         isError = true;
     }
     else if (salary.match(letters)) {
         document.getElementById('Label8').innerHTML = 'Enter valid salary';
         isError = true;
     }
     else if (salary < "1") {
         document.getElementById('Label8').innerHTML = 'Enter valid salary';
         isError = true;
     }
    
    if (isError) {
        return false;
    }
    else {
        return true;
    }
}