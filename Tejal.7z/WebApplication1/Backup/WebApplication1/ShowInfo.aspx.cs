﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class ShowInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.PreviousPage != null)
            {
                    TextBox SourceTextBox = (TextBox)Page.PreviousPage.FindControl("TextBox1");
                    lblEmployeeID.Text = SourceTextBox.Text;

                    TextBox SourceTextBox1 = (TextBox)Page.PreviousPage.FindControl("TextBox2");
                    Label1.Text = SourceTextBox1.Text;

                    TextBox SourceTextBox2 = (TextBox)Page.PreviousPage.FindControl("TextBox3");
                    Label2.Text = SourceTextBox2.Text;

                    TextBox SourceTextBox3 = (TextBox)Page.PreviousPage.FindControl("TextBox4");
                    Label3.Text = SourceTextBox3.Text;


                    TextBox SourceTextBox4 = (TextBox)Page.PreviousPage.FindControl("TextBox5");
                    Label4.Text = SourceTextBox4.Text;


                    TextBox SourceTextBox5 = (TextBox)Page.PreviousPage.FindControl("TextBox6");
                    Label5.Text = SourceTextBox5.Text;


                    DropDownList SourceTextBox7 = (DropDownList)Page.PreviousPage.FindControl("ddlDesignation");
                    Label6.Text = SourceTextBox7.SelectedItem.ToString();

                    TextBox SourceTextBox6 = (TextBox)Page.PreviousPage.FindControl("TextBox8");
                    Label7.Text = SourceTextBox6.Text;

                    DropDownList SourceTextBox8 = (DropDownList)Page.PreviousPage.FindControl("ddlDepartment");
                    Label8.Text = SourceTextBox8.SelectedItem.ToString();


            }
            //if (Request.Cookies["Username"] != null)
            //{
            //    Response.Write(Request.Cookies["Username"].Value.ToString());
            //}  
        }
    }
}