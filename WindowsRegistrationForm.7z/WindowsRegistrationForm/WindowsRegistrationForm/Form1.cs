﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;


namespace WindowsRegistrationForm
{
    public partial class t : Form
    {
               Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;

        public t()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (empID.Text == string.Empty)
            {
                MessageBox.Show("Please enter Employee ID");
                return;
            }

            else if (firstName.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(firstName.Text, "^[a-zA-Z]"))
            {
                MessageBox.Show("Please enter valid first name");
                return;
            }

            else if (lastName.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(lastName.Text, "[a-zA-Z]"))
            {
                MessageBox.Show("Please enter valid last name");
                return;
            }

            else if (address.Text == string.Empty)
            {
                MessageBox.Show("Please enter address");
                return;
            }

            else if (dob.Text == string.Empty)
            {
                MessageBox.Show("Please enetr a valid date");
                return;
            }

            else if (contact.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(contact.Text, ""))
            {
                MessageBox.Show("Please enter a valid contact");
                return;
            }

            else if (cmbDesignation.SelectedIndex == -1)
            {
                MessageBox.Show("please select a designation");
                return;
            }


            else if (salary.Text == string.Empty)
            {
                MessageBox.Show("please enter a valid salary");
                return;
            }

            else if (cmbDepartment.SelectedIndex == -1)
            {
                MessageBox.Show("select a department");
                return;
            }
            else
            {
                MessageBox.Show("hii");

                int _lastRow = xlWorkSheet.Range["A" + xlWorkSheet.Rows.Count].End[Excel.XlDirection.xlUp].Row + 1;

                xlWorkSheet.Cells[_lastRow, 1] = textBox1.Text;
                xlWorkSheet.Cells[_lastRow, 2] = textBox2.Text;
                xlWorkSheet.Cells[_lastRow, 3] = textBox3.Text;
                xlWorkSheet.Cells[_lastRow, 4] = textBox4.Text;
                xlWorkSheet.Cells[_lastRow, 5] = dobPicker.Text;
                xlWorkSheet.Cells[_lastRow, 6] = textBox5.Text;
                xlWorkSheet.Cells[_lastRow, 7] = cmbDesignation.Text;
                xlWorkSheet.Cells[_lastRow, 8] = textBox7.Text;
                xlWorkSheet.Cells[_lastRow, 9] = cmbDepartment.Text;

            }

        }


 
        // reset 

        private void btnReset_Click(object sender, EventArgs e)
        {
            ClearSpace(this);
        }

     
        public static void ClearSpace(Control control)
        {
            foreach (Control c in control.Controls)
            {
                var textBox = c as TextBox;
                var comboBox = c as ComboBox;

                if (textBox != null)
                    (textBox).Clear();

                if (comboBox != null)
                    comboBox.SelectedIndex = -1;

                if (c.HasChildren)
                    ClearSpace(c);
            }
        }

    

        private void btnClose_Click(object sender, EventArgs e)
        {
        
        
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            xlApp.Visible = true;



            // Open a File
            xlWorkBook = xlApp.Workbooks.Open("D:\\rajkumar\\dotnet\\csharp.xlsx", 0, true, 5, "", "", true,
            Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);

            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            xlWorkSheet.Cells[1, 1] = "Employee ID";
            xlWorkSheet.Cells[1, 2] = "First Name";
            xlWorkSheet.Cells[1, 3] = "Last Name";
            xlWorkSheet.Cells[1, 4] = "Address";
            xlWorkSheet.Cells[1, 5] = "DOB";
            xlWorkSheet.Cells[1, 6] = "Contact";
            xlWorkSheet.Cells[1, 7] = "Designation";
            xlWorkSheet.Cells[1, 8] = "Salary";
            xlWorkSheet.Cells[1, 9] = "Department";


        }

  

          

           


          

            

            

            

        }
    }
