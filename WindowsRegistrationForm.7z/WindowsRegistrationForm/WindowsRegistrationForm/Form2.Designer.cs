﻿namespace WindowsRegistrationForm
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.department = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.salary = new System.Windows.Forms.Label();
            this.designation = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.contact = new System.Windows.Forms.Label();
            this.dob = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lastName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.firstName = new System.Windows.Forms.Label();
            this.txtEmpID = new System.Windows.Forms.TextBox();
            this.empID = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // department
            // 
            this.department.AutoSize = true;
            this.department.Location = new System.Drawing.Point(74, 359);
            this.department.Name = "department";
            this.department.Size = new System.Drawing.Size(62, 13);
            this.department.TabIndex = 43;
            this.department.Text = "Department";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(600, 501);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 42;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(205, 306);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.ReadOnly = true;
            this.txtSalary.Size = new System.Drawing.Size(149, 20);
            this.txtSalary.TabIndex = 39;
            // 
            // salary
            // 
            this.salary.AutoSize = true;
            this.salary.Location = new System.Drawing.Point(74, 306);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(36, 13);
            this.salary.TabIndex = 38;
            this.salary.Text = "Salary";
            // 
            // designation
            // 
            this.designation.AutoSize = true;
            this.designation.Location = new System.Drawing.Point(74, 263);
            this.designation.Name = "designation";
            this.designation.Size = new System.Drawing.Size(63, 13);
            this.designation.TabIndex = 37;
            this.designation.Text = "Designation";
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(205, 226);
            this.txtContact.Name = "txtContact";
            this.txtContact.ReadOnly = true;
            this.txtContact.Size = new System.Drawing.Size(149, 20);
            this.txtContact.TabIndex = 36;
            // 
            // contact
            // 
            this.contact.AutoSize = true;
            this.contact.Location = new System.Drawing.Point(73, 226);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(44, 13);
            this.contact.TabIndex = 35;
            this.contact.Text = "Contact";
            // 
            // dob
            // 
            this.dob.AutoSize = true;
            this.dob.Location = new System.Drawing.Point(73, 181);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(30, 13);
            this.dob.TabIndex = 33;
            this.dob.Text = "DOB";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(205, 144);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.ReadOnly = true;
            this.txtAddress.Size = new System.Drawing.Size(149, 20);
            this.txtAddress.TabIndex = 32;
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Location = new System.Drawing.Point(73, 144);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(45, 13);
            this.address.TabIndex = 31;
            this.address.Text = "Address";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(205, 106);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.ReadOnly = true;
            this.txtLastName.Size = new System.Drawing.Size(149, 20);
            this.txtLastName.TabIndex = 30;
            // 
            // lastName
            // 
            this.lastName.AutoSize = true;
            this.lastName.Location = new System.Drawing.Point(72, 106);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(58, 13);
            this.lastName.TabIndex = 29;
            this.lastName.Text = "Last Name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(205, 71);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.ReadOnly = true;
            this.txtFirstName.Size = new System.Drawing.Size(149, 20);
            this.txtFirstName.TabIndex = 28;
            // 
            // firstName
            // 
            this.firstName.AutoSize = true;
            this.firstName.Location = new System.Drawing.Point(73, 71);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(57, 13);
            this.firstName.TabIndex = 27;
            this.firstName.Text = "First Name";
            // 
            // txtEmpID
            // 
            this.txtEmpID.Location = new System.Drawing.Point(205, 32);
            this.txtEmpID.Name = "txtEmpID";
            this.txtEmpID.Size = new System.Drawing.Size(149, 20);
            this.txtEmpID.TabIndex = 26;
            // 
            // empID
            // 
            this.empID.AutoSize = true;
            this.empID.Location = new System.Drawing.Point(73, 35);
            this.empID.Name = "empID";
            this.empID.Size = new System.Drawing.Size(67, 13);
            this.empID.TabIndex = 25;
            this.empID.Text = "Employee ID";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(431, 29);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 46;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(205, 181);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.ReadOnly = true;
            this.txtDOB.Size = new System.Drawing.Size(149, 20);
            this.txtDOB.TabIndex = 47;
            this.txtDOB.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txtDesignation
            // 
            this.txtDesignation.Location = new System.Drawing.Point(205, 263);
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.ReadOnly = true;
            this.txtDesignation.Size = new System.Drawing.Size(149, 20);
            this.txtDesignation.TabIndex = 48;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(205, 359);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.ReadOnly = true;
            this.txtDepartment.Size = new System.Drawing.Size(149, 20);
            this.txtDepartment.TabIndex = 49;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 589);
            this.Controls.Add(this.txtDepartment);
            this.Controls.Add(this.txtDesignation);
            this.Controls.Add(this.txtDOB);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.department);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.salary);
            this.Controls.Add(this.designation);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.contact);
            this.Controls.Add(this.dob);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.address);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.txtEmpID);
            this.Controls.Add(this.empID);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label department;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.Label salary;
        private System.Windows.Forms.Label designation;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label contact;
        private System.Windows.Forms.Label dob;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label firstName;
        private System.Windows.Forms.TextBox txtEmpID;
        private System.Windows.Forms.Label empID;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.TextBox txtDepartment;
    }
}