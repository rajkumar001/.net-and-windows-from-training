﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ParseHTML.Startup))]
namespace ParseHTML
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
