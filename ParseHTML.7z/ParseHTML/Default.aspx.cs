﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HtmlAgilityPack;
using System.Net.Http;
using System.Text;
using System.Net;
using System.IO;


public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Parsing("https://www.w3schools.com/css/css_website_layout.asp");
    }
    private async void Parsing(string website)
    {
        HttpClient http = new HttpClient();
        var response = await http.GetByteArrayAsync(website);
        String source = Encoding.GetEncoding("utf-8").GetString(response, 0, response.Length - 1);
        //String source = File.ReadAllText(website);
        source = WebUtility.HtmlDecode(source);
        HtmlDocument resultant = new HtmlDocument();
        resultant.LoadHtml(source);

        List<HtmlNode> toftitle = resultant.DocumentNode.Descendants().Where
        (x => (x.Name == "div" && x.Attributes["class"] != null &&
   x.Attributes["class"].Value.Contains("w3-col l3 m4"))).ToList();
        //Label.Text = toftitle[0].InnerText + toftitle[1].InnerText + toftitle[2].InnerText;
        for (int i = 0; i < 2500; i++) {
            int j =  1;
            j = j + 1;
        }

        foreach(HtmlNode i in toftitle)
        {
           if( i.InnerText.Contains("Angular"))
           {
               Label.Text = i.InnerText + System.Environment.NewLine;
           }
        }
    }
}