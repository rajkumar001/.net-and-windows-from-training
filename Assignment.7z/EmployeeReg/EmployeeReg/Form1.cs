﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace EmployeeReg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

 








        
    


        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == string.Empty)
            {
                MessageBox.Show("Please enter Employee ID");
                return;
            }
            else if (textBox2.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(textBox2.Text, "^[a-zA-Z]"))
            {
                MessageBox.Show("Please enter valid First Name!");
                return;
            }
            else if (textBox3.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(textBox3.Text, "^[a-zA-Z]"))
            {
                MessageBox.Show("Please enter valid Last Name!");
                return;
            }
            else if (textBox4.Text == string.Empty)
            {
                MessageBox.Show("Please enter Address!");
                return;
            }
            else if (textBox5.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(textBox5.Text, @"^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1}){0,1}9[0-9](\s){0,1}(\-){0,1}(\s){0,1}[1-9]{1}[0-9]{7}$"))
            {
                MessageBox.Show("Please enter valid Contact!");
                return;
            }
            else if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Designation!");
                return;
            }
            else if (textBox6.Text == string.Empty || !System.Text.RegularExpressions.Regex.IsMatch(textBox6.Text, "^[1-9]+[0-9]*$"))
            {
                MessageBox.Show("Please enter valid Salary!");
                return;
            }
            else if (comboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Please select Department!");
                return;
            }
            else
            {
                // Program logic...

                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
                Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;


                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed!!");
                    return;
                }
                if (!System.IO.File.Exists(@"d:\\csharp-Excel.xls"))
                {
                    xlWorkBook = xlApp.Workbooks.Add(misValue);

                    xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                    xlWorkSheet.Cells[1, 1] = "Employee ID";
                    xlWorkSheet.Cells[1, 2] = "First Name";
                    xlWorkSheet.Cells[1, 3] = "Last Name";
                    xlWorkSheet.Cells[1, 4] = "Address";
                    xlWorkSheet.Cells[1, 5] = "Date of Birth";
                    xlWorkSheet.Cells[1, 6] = "Contact";
                    xlWorkSheet.Cells[1, 7] = "Designation";
                    xlWorkSheet.Cells[1, 8] = "Salary";
                    xlWorkSheet.Cells[1, 9] = "Department";



                    int _lastRow = xlWorkSheet.Range["A" + xlWorkSheet.Rows.Count].End[Excel.XlDirection.xlUp].Row + 1;

                    xlWorkSheet.Cells[_lastRow, 1] = textBox1.Text;
                    xlWorkSheet.Cells[_lastRow, 2] = textBox2.Text;
                    xlWorkSheet.Cells[_lastRow, 3] = textBox3.Text;
                    xlWorkSheet.Cells[_lastRow, 4] = textBox4.Text;
                    xlWorkSheet.Cells[_lastRow, 5] = dateTimePicker1.Value.ToString("yyyy-MM-dd"); ;
                    xlWorkSheet.Cells[_lastRow, 6] = textBox5.Text;

                    xlWorkSheet.Cells[_lastRow, 7] = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
                    xlWorkSheet.Cells[_lastRow, 8] = textBox6.Text;
                    xlWorkSheet.Cells[_lastRow, 9] = this.comboBox2.GetItemText(this.comboBox2.SelectedItem);
                    xlWorkBook.SaveAs("d:\\csharp-Excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    xlWorkBook.Close(true, misValue, misValue);
                    MessageBox.Show("Data is saved to the excel file , you can find the file d:\\csharp-Excel.xls");
                    xlApp.Quit();
                    Marshal.ReleaseComObject(xlWorkSheet);
                    Marshal.ReleaseComObject(xlWorkBook);
                    Marshal.ReleaseComObject(xlApp);
                }
                else
                {

                    string path = @"d:\\csharp-Excel.xls";
                    xlApp = new Microsoft.Office.Interop.Excel.Application();
                    xlApp.Visible = true;
                    xlApp.DisplayAlerts = false;
                    xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
                    //Get all the sheets in the workbook
                    xlWorkSheets = xlWorkBook.Worksheets;
                    //Get the allready exists sheet
                    xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
                    Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

                    int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row + 1;
                    int flag = 0;

                    for (int i = 2; i <= _lastRow; i++)
                    {


                        String str = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);

                        if (textBox1.Text == str)
                        {

                            flag = 1;
                        }

                    }
                    MessageBox.Show("out for");
                    if (flag == 0)
                    {

                        xlSheet1.Cells[_lastRow, 1] = textBox1.Text;
                        xlSheet1.Cells[_lastRow, 2] = textBox2.Text;
                        xlSheet1.Cells[_lastRow, 3] = textBox3.Text;
                        xlSheet1.Cells[_lastRow, 4] = textBox4.Text;
                        xlSheet1.Cells[_lastRow, 5] = dateTimePicker1.Value.ToString("yyyy-MM-dd"); ;
                        xlSheet1.Cells[_lastRow, 6] = textBox5.Text;

                        xlSheet1.Cells[_lastRow, 7] = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
                        xlSheet1.Cells[_lastRow, 8] = textBox6.Text;
                        xlSheet1.Cells[_lastRow, 9] = this.comboBox2.GetItemText(this.comboBox2.SelectedItem);
                        xlWorkBook.SaveAs("d:\\csharp-Excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                        xlWorkBook.Close(true, misValue, misValue);
                        MessageBox.Show("Data is saved to the excel file , you can find the file d:\\csharp-Excel.xls");
                    }
                    else
                    {
                        MessageBox.Show("Employee Id is alerady present");
                    }
                    xlSheet1 = null;
                    xlWorkBook = null;
                    xlApp.Quit();

                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearSpace(this);
        }
        public static void ClearSpace(Control control)
        {
            foreach (Control c in control.Controls)
            {
                var textBox = c as TextBox;
                var comboBox = c as ComboBox;

                if (textBox != null)
                    (textBox).Clear();

                if (comboBox != null)
                    comboBox.SelectedIndex = -1;

                if (c.HasChildren)
                    ClearSpace(c);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure To Exit Programme ?", "Exit", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                Application.Exit();
            }
        

        }
  

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    

        private void Form1_Load_1(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Consultant");
            comboBox1.Items.Add("Sr.Consultant");
            comboBox1.Items.Add("Lead Consultant");
            comboBox1.Items.Add("Manager");
            comboBox1.Items.Add("Sr. Manager");
            comboBox2.Items.Add("IT");
            comboBox2.Items.Add("Admin");
            comboBox2.Items.Add("Facitilies");
            comboBox2.Items.Add("HR");
        }
    }
}
