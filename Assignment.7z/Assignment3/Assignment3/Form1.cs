﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace Assignment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Visible = true;
            comboBox2.Visible = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            comboBox2.Visible = true;
            comboBox1.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Excel.Workbook xlWorkBook;
            // Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet1;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets;
            Excel.Workbook xlWorkBook1;
            Excel.Worksheet xlWorkSheet1;
            object misValue1 = System.Reflection.Missing.Value;
            Excel.Application xlApp1 = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Worksheet xlSheet11;
            Microsoft.Office.Interop.Excel.Sheets xlWorkSheets1;
            String combo_Selection = "default";
            String radio_selection;

            bool isChecked = radioButton1.Checked;
            if (isChecked)
                radio_selection = radioButton1.Text;
            else
                radio_selection = radioButton2.Text;

            if (radio_selection == "Department Wise")
            {

                combo_Selection = comboBox1.SelectedItem.ToString();
            }
            else
            {
                combo_Selection = comboBox2.SelectedItem.ToString();

            }


            string path = @"d:\\csharp-Excel.xls";
            xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;
            xlApp.DisplayAlerts = false;
            xlWorkBook = xlApp.Workbooks.Open(path, 0, false, 5, "", "", false, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", true, false, 0, true, false, false);
            //Get all the sheets in the workbook
            xlWorkSheets = xlWorkBook.Worksheets;
            //Get the allready exists sheet
            xlSheet1 = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkSheets.get_Item("Sheet1");
            Microsoft.Office.Interop.Excel.Range range = xlSheet1.UsedRange;

            int _lastRow = xlSheet1.Range["A" + xlSheet1.Rows.Count].End[Excel.XlDirection.xlUp].Row;
            int _lastcol = xlSheet1.Range["A" + xlSheet1.Columns.Count].End[Excel.XlDirection.xlUp].Column;




            if (xlApp1 == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            if (!System.IO.File.Exists(@"d:\\csharp-Excel1.xls"))
            {
                xlWorkBook1 = xlApp1.Workbooks.Add(misValue1);

                xlWorkSheet1 = (Excel.Worksheet)xlWorkBook1.Worksheets.get_Item(1);
                xlWorkSheet1.Cells[1, 1] = "Employee ID";
                xlWorkSheet1.Cells[1, 2] = "First Name";
                xlWorkSheet1.Cells[1, 3] = "Last Name";
                xlWorkSheet1.Cells[1, 4] = "Address";
                xlWorkSheet1.Cells[1, 5] = "Date of Birth";
                xlWorkSheet1.Cells[1, 6] = "Contact";
                xlWorkSheet1.Cells[1, 7] = "Designation";
                xlWorkSheet1.Cells[1, 8] = "Salary";
                xlWorkSheet1.Cells[1, 9] = "Department";


                int j = 2;
                for (int i = 2; i <= _lastRow; i++)
                {

                    if (combo_Selection == Convert.ToString((range.Cells[i, 9] as Excel.Range).Value2))
                    {

                        xlWorkSheet1.Cells[j, 1] = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 2] = Convert.ToString((range.Cells[i, 2] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 3] = Convert.ToString((range.Cells[i, 3] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 4] = Convert.ToString((range.Cells[i, 4] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 5] = Convert.ToString((range.Cells[i, 5] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 6] = Convert.ToString((range.Cells[i, 6] as Excel.Range).Value2);

                        xlWorkSheet1.Cells[j, 7] = Convert.ToString((range.Cells[i, 7] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 8] = Convert.ToString((range.Cells[i, 8] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 9] = Convert.ToString((range.Cells[i, 9] as Excel.Range).Value2);
                        j++;
                    }
                    else if (combo_Selection == Convert.ToString((range.Cells[i, 7] as Excel.Range).Value2))
                    {
                        xlWorkSheet1.Cells[j, 1] = Convert.ToString((range.Cells[i, 1] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 2] = Convert.ToString((range.Cells[i, 2] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 3] = Convert.ToString((range.Cells[i, 3] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 4] = Convert.ToString((range.Cells[i, 4] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 5] = Convert.ToString((range.Cells[i, 5] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 6] = Convert.ToString((range.Cells[i, 6] as Excel.Range).Value2);

                        xlWorkSheet1.Cells[j, 7] = Convert.ToString((range.Cells[i, 7] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 8] = Convert.ToString((range.Cells[i, 8] as Excel.Range).Value2);
                        xlWorkSheet1.Cells[j, 9] = Convert.ToString((range.Cells[i, 9] as Excel.Range).Value2);
                        j++;
                    }


                }

                xlWorkBook1.SaveAs("d:\\report.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook1.Close(true, misValue, misValue);
                MessageBox.Show("Data is saved to the excel file , you can find the file d:\\report.xls");
                xlApp1.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet1);
                Marshal.ReleaseComObject(xlWorkBook1);








                xlWorkBook.Close(true, misValue, misValue);


                xlSheet1 = null;
                xlWorkBook = null;
                xlApp.Quit();

                GC.WaitForPendingFinalizers();
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();


            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("IT");
            comboBox1.Items.Add("Admin");
            comboBox1.Items.Add("Facitilies");
            comboBox1.Items.Add("HR");

            comboBox2.Items.Add("Consultant");
            comboBox2.Items.Add("Sr.Consultant");
            comboBox2.Items.Add("Lead Consultant");
            comboBox2.Items.Add("Manager");
            comboBox2.Items.Add("Sr. Manager");
        }
    }
}
